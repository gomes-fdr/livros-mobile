angular.module('app.controllers', [])
  
.controller('listaDeLivrosCtrl', function($scope, $firebaseObject) {

	var syncObject = $firebaseObject(fb.child("books/"));
	syncObject.$bindTo($scope, "books");

})
   
.controller('signupCtrl', function($scope) {

})
   
.controller('detalhesDoLivroCtrl', function($scope) {

})
   
.controller('detalhesDoLivro2Ctrl', function($scope) {

})
   
.controller('negociaODoLivroCtrl', function($scope) {

})
   
.controller('meusLivrosCtrl', function($scope) {

})
   
.controller('livroCtrl', function($scope) {

})
 